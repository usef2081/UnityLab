using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    // Start is called before the first frame update

    private CharacterController controller;
    private Vector3 direction;
    public float goingSpeed;
    public GameObject NukeText;
    public GameObject MultiplierText;
    public GameObject ShieldText;

    Renderer ren;
    private int wantedLane = 1;
    public float laneGap = 2;
    
    void Start()
    {
        ren = GetComponent<Renderer>();
        controller = GetComponent<CharacterController>();

    }

    // Update is called once per frame
    void Update()
    {


        if(PlayerManager.red_sp == true)
        {

            NukeText.SetActive(true);

        }
        else
        {

            NukeText.SetActive(false);
        }



        if (PlayerManager.green_sp == true)
        {

            MultiplierText.SetActive(true);

        }
        else
        {

            MultiplierText.SetActive(false);
        }


        if (PlayerManager.blue_sp == true)
        {

            ShieldText.SetActive(true);

        }
        else
        {

            ShieldText.SetActive(false);
        }



        if ((PlayerManager.RedForm == true) && (PlayerManager.RedEnergy == 0))
        {
            PlayerManager.RedForm = false;
            PlayerManager.GreenForm = false;
            PlayerManager.BlueForm = false;
            PlayerManager.red_sp = false;
            PlayerManager.blue_sp = false;
            PlayerManager.green_sp = false;
            ren.material.color = Color.white;
        }



        if ((PlayerManager.GreenForm == true) && (PlayerManager.GreenEnergy == 0))
        {
            PlayerManager.RedForm = false;
            PlayerManager.GreenForm = false;
            PlayerManager.BlueForm = false;
            PlayerManager.red_sp = false;
            PlayerManager.blue_sp = false;
            PlayerManager.green_sp = false;
            ren.material.color = Color.white;
        }


        if ((PlayerManager.BlueForm == true) && (PlayerManager.BlueEnergy == 0))
        {
            PlayerManager.RedForm = false;
            PlayerManager.GreenForm = false;
            PlayerManager.BlueForm = false;
            PlayerManager.red_sp = false;
            PlayerManager.blue_sp = false;
            PlayerManager.green_sp = false;
            ren.material.color = Color.white;
        }










        if (Input.GetKeyDown(KeyCode.J))
        {

            if(PlayerManager.RedEnergy == 5)
            {
                PlayerManager.RedEnergy--;
                PlayerManager.RedForm = true;
                PlayerManager.GreenForm = false;
                PlayerManager.BlueForm = false;
                PlayerManager.red_sp = false;
                PlayerManager.green_sp = false;
                PlayerManager.blue_sp = false;
                ren.material.color = Color.red;
                

            }


        }



        if (Input.GetKeyDown(KeyCode.K))
        {

            if (PlayerManager.GreenEnergy == 5)
            {
                PlayerManager.GreenEnergy--;
                PlayerManager.GreenForm = true;
                PlayerManager.RedForm = false;
                PlayerManager.BlueForm = false;
                PlayerManager.red_sp = false;
                PlayerManager.green_sp = false;
                PlayerManager.blue_sp = false;
                ren.material.color = Color.green;

            }


        }


        if (Input.GetKeyDown(KeyCode.L))
        {

            if (PlayerManager.BlueEnergy == 5)
            {
                PlayerManager.BlueEnergy--;
                PlayerManager.BlueForm = true;
                PlayerManager.RedForm = false;
                PlayerManager.GreenForm = false;
                PlayerManager.red_sp = false;
                PlayerManager.green_sp = false;
                PlayerManager.blue_sp = false;
                ren.material.color = Color.blue;

            }


        }

        if (Input.GetKeyDown(KeyCode.Space))
        {

            if((PlayerManager.RedForm == true) && (PlayerManager.red_sp == false))
            {
                
                PlayerManager.RedEnergy--;
                PlayerManager.red_sp = true;
                PlayerManager.green_sp = false;
                PlayerManager.blue_sp = false;
                GroundManager.removeObstacles();
                

            }


            if ((PlayerManager.GreenForm == true) && (PlayerManager.green_sp == false))
            {
                PlayerManager.GreenEnergy--;
                PlayerManager.green_sp = true;
                PlayerManager.red_sp = false;
                PlayerManager.blue_sp = false;

            }


            if ((PlayerManager.BlueForm == true) && (PlayerManager.blue_sp == false))
            {
                PlayerManager.BlueEnergy--;
                PlayerManager.blue_sp = true;
                PlayerManager.red_sp = false;
                PlayerManager.green_sp = false;
                

            }


        } 




        direction.z = goingSpeed;

        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D))
        {
            wantedLane++;
            if (wantedLane == 3)
            {
                wantedLane = 2;
            }

        }




        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A))
        {
            wantedLane--;
            if (wantedLane == -1)
            {
                wantedLane = 0;
            }
        }


        Vector3 newPosition = (transform.position.z * transform.forward) + (transform.position.y * transform.up);

        if (wantedLane == 0)
        {
            newPosition += Vector3.left * laneGap;

        }

        else if (wantedLane == 2)
        {
            newPosition += Vector3.right * laneGap;

        }

        transform.position = Vector3.Lerp(transform.position , newPosition, 10 * Time.deltaTime);
        controller.center = controller.center;
        //transform.position = newPosition;

        


         


    }


    private void FixedUpdate()
    {
        controller.Move(direction * Time.fixedDeltaTime);

    }




    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if(hit.transform.tag == "Obstacle")
        {

            if ((PlayerManager.RedForm == false) && (PlayerManager.BlueForm == false) && (PlayerManager.GreenForm == false)) 
            {

                PlayerManager.endGame = true;
                
            }


            if(PlayerManager.blue_sp == true)
            {
                hit.gameObject.SetActive(false);
                PlayerManager.blue_sp = false;

            }
            else
            {
                hit.gameObject.SetActive(false);
                PlayerManager.RedForm = false;
                PlayerManager.GreenForm = false;
                PlayerManager.BlueForm = false;
                PlayerManager.red_sp = false;
                PlayerManager.blue_sp = false;
                PlayerManager.green_sp = false;
                ren.material.color = Color.white;
                
            }


            
        }
    }
}

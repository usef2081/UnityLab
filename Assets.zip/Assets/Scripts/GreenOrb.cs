using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenOrb : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }



    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" && (PlayerManager.GreenForm == false))
        {
            PlayerManager.GreenEnergy += 1;
            PlayerManager.score += 1;
            Destroy(gameObject);
        }

        if (other.tag == "Player" && (PlayerManager.GreenForm == true))
        {

            if (PlayerManager.green_sp == true)
            {

                PlayerManager.score += 10;
                Destroy(gameObject);


            }
            else
            {
                PlayerManager.score += 2;
                Destroy(gameObject);
            }


        }
    }
}

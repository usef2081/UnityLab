using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{

    public Audio[] sounds;  
    // Start is called before the first frame update
    void Start()
    {

        foreach(Audio x in sounds)
        {
            x.source = gameObject.AddComponent<AudioSource>();   
            x.source.clip = x.clip;
            x.source.loop = x.loop;
        }

        PlayAudio("GamePlayTheme");
        
    }

    public void PlayAudio(string title)
    {
        foreach(Audio x in sounds)
        {
            if(x.title == title)
            {
                x.source.Play();
            }
        }
    }




    // Update is called once per frame
    void Update()
    {
        
    }
}

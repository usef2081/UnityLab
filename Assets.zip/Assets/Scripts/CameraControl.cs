using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    public Transform followed;
    private Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
        offset = transform.position - followed.position;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 newP = new Vector3(transform.position.x , transform.position.y, offset.z+followed.position.z);
        transform.position = newP;
    }
}

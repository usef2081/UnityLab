using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    // Start is called before the first frame update


    public GameObject pausePanel;
    public bool paused = false;




    private void Update()
    {
        if(Input.GetKeyUp(KeyCode.Escape))
        {

            if (paused)
            {

                Resume();
            }

            else
            {

                PauseGame();

            }


        }
    }
    public void RestartGame()
    {
        SceneManager.LoadScene("MainScene");

    }

    public void MainMenu()
    {

        SceneManager.LoadScene("Main Menu");
    }

    public void Resume()
    {
        pausePanel.SetActive(false);    
        Time.timeScale = 1.0f;
        paused = false;
    }


    public void PauseGame()
    {
        pausePanel.SetActive(true);
        Time.timeScale = 0.0f;
        paused = true;
    }





}

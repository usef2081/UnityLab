using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueOrb : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" && (PlayerManager.BlueForm == false))
        {
            if (PlayerManager.green_sp == true)
            {
                PlayerManager.score += 5;
                PlayerManager.BlueEnergy += 2;
                Destroy(gameObject);

            }
            else {
                PlayerManager.BlueEnergy += 1;
                PlayerManager.score += 1;
                Destroy(gameObject);
            }
            PlayerManager.green_sp = false; 
        }

        if (other.tag == "Player" && (PlayerManager.BlueForm == true))
        {

            PlayerManager.score += 2;
            Destroy(gameObject);


        }
    }


}




using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public class GroundManager : MonoBehaviour
{

    public GameObject[] itemPrefabs;
    
    public GameObject ground;


    public float adjust_y_orbs = 0.7f;
    public float adjust_y_obstacles = 1.4f;


    public float right_t = 2.5f;
    public float left_t = -2.5f;


    public float obstacle_r = -89.98f;

    public float Znew = 30;
    public float Z_Item = 15;


    public float groundLength = 30;
    public int numberOfGround = 4;


    private List<GameObject> activeGround = new List<GameObject>();
    private static List<GameObject> activeItems = new List<GameObject>();
    
    public Transform playerTransform;
    public static float player_z;


    // Start is called before the first frame update
    void Start()

    {
        
        activeItems.Add(null);
        activeItems.Add(null);
        activeItems.Add(null);
        activeItems.Add(null);
        activeItems.Add(null);
        activeItems.Add(null);
        for (int i = 0; i < numberOfGround; i++)
        {
            //if (i == 0)
                //generateGround(0);
            
                generateGround();
               
                   
        }

        generateItems();
        //Z_Item += 15;
    }

    // Update is called once per frame
    void Update()
    {
        player_z = playerTransform.position.z;





        if ( Z_Item - playerTransform.position.z  < 15)
        {
            generateItems();
            
            
            
            generateItems();

            // Z_Item += 15;

            deleteItem();
            generateItems();








        }


        if (playerTransform.position.z - 35 > Znew - (numberOfGround * groundLength))
        {
            generateGround();
            deleteGround();
            

        }

    }


   public static void removeObstacles ()
    {

        
        foreach (GameObject item in activeItems) 
        
        { 
           if(item!= null && item.CompareTag("Obstacle") == true && item.transform.position.z > player_z )
            {
                Destroy(item);
            }
        
        }


    }
   


    public void generateGround() 
    
    {

        GameObject copy = Instantiate(ground, transform.forward * Znew, transform.rotation);
        activeGround.Add(copy);
        Znew += groundLength;
        
        
    
    }



    public void generateItems()
    {
            
        int obstacle_count = 0;
        int leftlane = Random.Range(0,itemPrefabs.Length);
        int midlane = Random.Range(0, itemPrefabs.Length);
        int rightlane;

        


        if(leftlane != 0)
        {
            if (leftlane == 4)
            {
                obstacle_count++;
                GameObject leftitem = Instantiate(itemPrefabs[leftlane], transform.forward * Z_Item + (transform.up * adjust_y_obstacles) +transform.right*left_t, transform.rotation);
                leftitem.transform.Rotate(Vector3.right, obstacle_r);
                activeItems.Add(leftitem);
            }
            else
            {
                GameObject leftitem = Instantiate(itemPrefabs[leftlane], transform.forward * Z_Item + (transform.up * adjust_y_orbs)+transform.right * left_t, transform.rotation);
                activeItems.Add(leftitem);
            }
        }


        if (midlane != 0)
        {
            if (midlane == 4)
            {
                obstacle_count++;
                GameObject miditem = Instantiate(itemPrefabs[midlane], transform.forward * Z_Item + (transform.up * adjust_y_obstacles), transform.rotation);
                miditem.transform.Rotate(Vector3.right, obstacle_r);
                activeItems.Add(miditem);
            }
            else
            {
                GameObject miditem = Instantiate(itemPrefabs[midlane], transform.forward * Z_Item + (transform.up * adjust_y_orbs), transform.rotation);
                activeItems.Add(miditem);
            }
        }

        
        
            if (obstacle_count<2)
            {
                rightlane = Random.Range(0, itemPrefabs.Length);
            if (rightlane != 0)
            {
                if (rightlane == 4)
                {
                    GameObject rightitem = Instantiate(itemPrefabs[rightlane], transform.forward * Z_Item + (transform.up * adjust_y_obstacles)+transform.right * right_t, transform.rotation);
                    rightitem.transform.Rotate(Vector3.right, obstacle_r);
                    activeItems.Add(rightitem);
                }
                else
                {
                    GameObject rightitem = Instantiate(itemPrefabs[rightlane], transform.forward * Z_Item + (transform.up * adjust_y_orbs) + transform.right * right_t, transform.rotation);
                    activeItems.Add(rightitem);

                }
            }
            }

            else
             {
                 rightlane = Random.Range(0, itemPrefabs.Length-1);
                    if (rightlane != 0)
                {

                GameObject rightitem = Instantiate(itemPrefabs[rightlane], transform.forward * Z_Item + (transform.up * adjust_y_orbs) + transform.right * right_t, transform.rotation);
                activeItems.Add(rightitem);
                }

                }

            if(leftlane == 0 || rightlane == 0 || midlane == 0)
        {
            activeItems.Add(null);
        }






        Z_Item += 15;



    }

    private void deleteItem()
    {
        if (activeItems.Count >= 6)
        {

            for (int i = 0; i < 6; i++)
            {
                Destroy(activeItems[0]);
                activeItems.RemoveAt(0);
            }
        }
    }


    private void deleteGround()
    {

        Destroy(activeGround[0]);
        activeGround.RemoveAt(0);
    }
}

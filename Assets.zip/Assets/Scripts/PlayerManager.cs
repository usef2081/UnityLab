using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour
{
    public static bool endGame;
    public GameObject gameOverPanel;
    public static int RedEnergy;
    public static int GreenEnergy;
    public static int BlueEnergy;
    public static int score;

    public static bool RedForm;
    public static bool GreenForm;
    public static bool BlueForm;


    public static bool red_sp;
    public static bool green_sp;
    public static bool blue_sp;

    public Text RedText;
    public Text GreenText;
    public Text BlueText;
    public Text ScoreText;  
    // Start is called before the first frame update
    void Start()
    {
        endGame = false;
        Time.timeScale = 1;  
        score = 0;  
        RedEnergy = 0;
        GreenEnergy = 0;    
        BlueEnergy = 0; 
    }

    // Update is called once per frame
    void Update()

    {






        if (endGame)

        {
            Time.timeScale = 0; 
            gameOverPanel.SetActive(true);
        }


        if(RedEnergy > 5)
        {
            RedEnergy = 5;
        }

        if (GreenEnergy > 5)
        {
            GreenEnergy = 5;
        }


        if (BlueEnergy > 5)
        {
            BlueEnergy = 5;
        }


        ScoreText.text = "Score: " + score;
        RedText.text = "Red --> " + RedEnergy;
        GreenText.text = "Green --> " + GreenEnergy;
        BlueText.text = "Blue --> " + BlueEnergy;

    }
}

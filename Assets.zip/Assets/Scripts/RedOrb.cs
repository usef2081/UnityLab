using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedOrb : MonoBehaviour
{



   
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
    }



    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player" && (PlayerManager.RedForm == false))
        {
            if (PlayerManager.green_sp == true)
            {
                PlayerManager.score += 5;
                PlayerManager.RedEnergy += 2;
                Destroy(gameObject);

            }
            else {
                PlayerManager.RedEnergy += 1;
                PlayerManager.score += 1;
                Destroy(gameObject);
            }
            PlayerManager.green_sp = false;
        }

        if (other.tag == "Player" && (PlayerManager.RedForm == true))
        {

            PlayerManager.score += 2;
            Destroy(gameObject);
            


        }




    }
}
